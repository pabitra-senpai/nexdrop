/* ================================================================
   MediaStream v5.0 — popup.js
   Features: Video/Audio/iFrame/Image/HLS+DASH scan, preview lightbox,
             video duration, image resolution, file size, batch download,
             JSON/CSV/MD export, XSS-safe DOM, full error handling.
   ================================================================ */

'use strict';

// ── State ──────────────────────────────────────────────────────
let allMedia    = [];
let activeFilter = 'all';
let searchQuery  = '';
let dlQueue      = [];

// ── DOM refs ───────────────────────────────────────────────────
const scanBtn      = document.getElementById('scanBtn');
const scanLabel    = document.getElementById('scanLabel');
const statsRow     = document.getElementById('statsRow');
const toolbar      = document.getElementById('toolbar');
const filterChips  = document.getElementById('filterChips');
const divider      = document.getElementById('divider');
const mediaList    = document.getElementById('mediaList');
const searchInp    = document.getElementById('searchInp');
const copyAllBtn   = document.getElementById('copyAllBtn');
const exportBtn    = document.getElementById('exportBtn');
const exportMenu   = document.getElementById('exportMenu');
const clearBtn     = document.getElementById('clearBtn');
const statusDot    = document.getElementById('statusDot');
const statusLabel  = document.getElementById('statusLabel');
const countLabel   = document.getElementById('countLabel');
const countNum     = document.getElementById('countNum');
const dlQueueEl    = document.getElementById('dlQueue');
const dlList       = document.getElementById('dlList');
const clearQueueBtn= document.getElementById('clearQueueBtn');

// ── Helpers ────────────────────────────────────────────────────
const $ = (id) => document.getElementById(id);
const sanitizeUrl = (url) => {
  try {
    const u = new URL(url);
    if (!['http:', 'https:', 'blob:', 'data:'].includes(u.protocol)) return null;
    return u.href;
  } catch { return null; }
};

const safeText = (str) => {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
};

function setStatus(state, text) {
  statusDot.className = 'status-dot' + (state ? ' ' + state : '');
  statusLabel.textContent = text;
}

function setDashboard(show) {
  [statsRow, toolbar, filterChips, divider].forEach(el => el.classList.toggle('hidden', !show));
  countLabel.classList.toggle('hidden', !show);
}

function updateStats() {
  $('cntVideo').textContent  = allMedia.filter(m => m.type === 'video').length;
  $('cntAudio').textContent  = allMedia.filter(m => m.type === 'audio').length;
  $('cntIframe').textContent = allMedia.filter(m => m.type === 'iframe').length;
  $('cntImage').textContent  = allMedia.filter(m => m.type === 'image').length;
}

// ── Scan ────────────────────────────────────────────────────────
scanBtn.addEventListener('click', async () => {
  scanBtn.classList.add('loading');
  scanLabel.textContent = 'Scanning…';
  setStatus('scanning', 'scanning');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || /^(chrome|chrome-extension|about|edge):/.test(tab.url)) {
      showError('Cannot scan this page — it\'s a protected browser tab.');
      resetScan(); setStatus('', 'idle');
      return;
    }

    chrome.scripting.executeScript(
      { target: { tabId: tab.id, allFrames: true }, function: pageScanner },
      (results) => {
        // ── Error handling ──────────────────────────────────────
        if (chrome.runtime.lastError) {
          showError('Scan failed: ' + chrome.runtime.lastError.message);
          resetScan(); setStatus('', 'idle');
          return;
        }

        const seen   = new Set();
        const merged = [];

        (results || []).forEach(frame => {
          if (!frame || !Array.isArray(frame.result)) return;
          frame.result.forEach(item => {
            if (item?.url && !seen.has(item.url)) {
              seen.add(item.url);
              merged.push(item);
            }
          });
        });

        allMedia = merged;
        resetScan();

        if (allMedia.length === 0) {
          showEmpty('Nothing Found', 'No media elements detected on this page.\nTry scrolling the page first, then scan again.');
          setStatus('', 'nothing found');
        } else {
          setDashboard(true);
          updateStats();
          renderMedia();
          fetchMeta();
          setStatus('active', `${allMedia.length} items`);
        }
      }
    );
  } catch (err) {
    showError('Unexpected error: ' + err.message);
    resetScan(); setStatus('', 'error');
  }
});

function resetScan() {
  scanBtn.classList.remove('loading');
  scanLabel.textContent = 'Scan Page for Media';
}

// ── Fetch metadata (size, resolution, duration) ─────────────────
async function fetchMeta() {
  for (const item of allMedia) {
    if (item.type === 'image') {
      fetchImageMeta(item);
    } else if (item.type === 'video' || item.type === 'audio') {
      fetchAVMeta(item);
    } else if (item.url && !item.size) {
      fetchHeadMeta(item);
    }
  }
}

function fetchImageMeta(item) {
  const img = new Image();
  img.onload = () => {
    item.resolution = `${img.naturalWidth}×${img.naturalHeight}`;
    item.size = estimateImageSize(img.naturalWidth, img.naturalHeight);
    refreshCard(item);
  };
  img.onerror = () => {};
  img.src = item.url;
}

function estimateImageSize(w, h) {
  const bytes = w * h * 3 * 0.12; // rough JPEG estimate
  return formatBytes(bytes);
}

function fetchAVMeta(item) {
  const el = item.type === 'video' ? document.createElement('video') : document.createElement('audio');
  el.preload = 'metadata';
  el.onloadedmetadata = () => {
    if (!isNaN(el.duration) && el.duration > 0) {
      item.duration = formatDuration(el.duration);
    }
    if (item.type === 'video' && el.videoWidth) {
      item.resolution = `${el.videoWidth}×${el.videoHeight}`;
    }
    refreshCard(item);
  };
  el.onerror = () => {};
  el.src = item.url;
}

async function fetchHeadMeta(item) {
  try {
    const res = await fetch(item.url, { method: 'HEAD', signal: AbortSignal.timeout(4000) });
    const cl = res.headers.get('content-length');
    if (cl) { item.size = formatBytes(parseInt(cl)); refreshCard(item); }
  } catch {}
}

function formatDuration(s) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return m + ':' + String(sec).padStart(2, '0');
}

function formatBytes(b) {
  if (b < 1024)     return b + ' B';
  if (b < 1048576)  return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}

// ── Render ─────────────────────────────────────────────────────
function getFiltered() {
  return allMedia.filter(m => {
    const matchType   = activeFilter === 'all'
      ? true
      : activeFilter === 'hls'
        ? m.isStream
        : m.type === activeFilter;
    const matchSearch = !searchQuery || m.url.toLowerCase().includes(searchQuery);
    return matchType && matchSearch;
  });
}

function renderMedia() {
  mediaList.innerHTML = '';
  const list = getFiltered();
  countNum.textContent = list.length;

  if (list.length === 0) {
    showEmpty('No Matches', 'Try a different filter or clear the search.');
    return;
  }

  list.forEach((item, i) => {
    const card = buildCard(item, i);
    mediaList.appendChild(card);
  });
}

// refresh a single card's meta pills without full re-render
function refreshCard(item) {
  const el = document.querySelector(`[data-url="${CSS.escape(item.url)}"] .meta-pills`);
  if (!el) return;
  el.innerHTML = buildMetaPills(item);
}

function buildMetaPills(item) {
  let html = '';
  if (item.isStream) html += `<span class="meta-pill hls">HLS/DASH</span>`;
  if (item.duration)   html += `<span class="meta-pill dur">${safeText(item.duration)}</span>`;
  if (item.resolution) html += `<span class="meta-pill res">${safeText(item.resolution)}</span>`;
  if (item.size)       html += `<span class="meta-pill size">${safeText(item.size)}</span>`;
  return html;
}

function buildCard(item, index) {
  const card = document.createElement('div');
  card.className = `media-card t-${item.type}`;
  card.dataset.url = item.url;
  card.style.animationDelay = `${Math.min(index * 25, 200)}ms`;

  // ── Thumbnail
  const thumb = document.createElement('div');
  thumb.className = 'thumb';

  const typeDot = document.createElement('div');
  typeDot.className = 'type-dot';
  thumb.appendChild(typeDot);

  if (item.type === 'image') {
    const img = document.createElement('img');
    img.src = item.url;
    img.alt = '';
    img.onerror = () => { thumb.innerHTML = '⊡'; thumb.appendChild(typeDot); };
    const overlay = document.createElement('div');
    overlay.className = 'thumb-overlay';
    overlay.textContent = '🔍';
    overlay.addEventListener('click', () => openLightbox(item));
    thumb.appendChild(img);
    thumb.appendChild(overlay);
  } else if (item.type === 'video') {
    const vid = document.createElement('video');
    vid.src = item.url;
    vid.muted = true;
    vid.preload = 'metadata';
    vid.loop = true;
    vid.addEventListener('mouseenter', () => vid.play().catch(() => {}));
    vid.addEventListener('mouseleave', () => vid.pause());
    const overlay = document.createElement('div');
    overlay.className = 'thumb-overlay';
    overlay.textContent = '▶';
    overlay.addEventListener('click', () => openLightbox(item));
    thumb.appendChild(vid);
    thumb.appendChild(overlay);
  } else if (item.type === 'audio') {
    thumb.textContent = '♫';
    thumb.appendChild(typeDot);
  } else {
    thumb.textContent = '⊞';
    thumb.appendChild(typeDot);
  }

  // ── Body
  const body = document.createElement('div');
  body.className = 'card-body';

  // header row
  const header = document.createElement('div');
  header.className = 'card-header';

  const typeTag = document.createElement('span');
  typeTag.className = 'type-tag';
  const labels = { video: '▶ Video', audio: '♫ Audio', iframe: '⊞ iFrame', image: '⊡ Image' };
  typeTag.textContent = labels[item.type] || item.type;

  const metaPills = document.createElement('div');
  metaPills.className = 'meta-pills';
  metaPills.innerHTML = buildMetaPills(item);

  header.appendChild(typeTag);
  header.appendChild(metaPills);

  // url
  const urlRow = document.createElement('div');
  urlRow.className = 'url-row';
  urlRow.title = item.url;
  urlRow.textContent = item.url.length > 55 ? item.url.substring(0, 52) + '…' : item.url;

  // actions
  const actions = document.createElement('div');
  actions.className = 'card-actions';

  const copyBtn = makeActionBtn('Copy URL', () => {
    navigator.clipboard.writeText(item.url).then(() => {
      copyBtn.textContent = '✓ Copied';
      copyBtn.classList.add('copied');
      setTimeout(() => { copyBtn.textContent = 'Copy URL'; copyBtn.classList.remove('copied'); }, 1400);
    });
  });

  const openBtn = makeActionBtn('Open ↗', () => chrome.tabs.create({ url: item.url }));
  openBtn.classList.add('open');

  const dlBtn = makeActionBtn('⬇ Download', () => downloadItem(item));
  dlBtn.classList.add('dl');

  actions.appendChild(copyBtn);
  if (item.type !== 'iframe') actions.appendChild(dlBtn);
  actions.appendChild(openBtn);

  body.appendChild(header);
  body.appendChild(urlRow);
  body.appendChild(actions);

  card.appendChild(thumb);
  card.appendChild(body);
  return card;
}

function makeActionBtn(label, onClick) {
  const btn = document.createElement('button');
  btn.className = 'action-btn';
  btn.textContent = label;
  btn.addEventListener('click', onClick);
  return btn;
}

// ── Lightbox ────────────────────────────────────────────────────
function openLightbox(item) {
  const lb = document.createElement('div');
  lb.className = 'lightbox';

  const content = document.createElement('div');
  content.className = 'lightbox-content';

  const closeBtn = document.createElement('button');
  closeBtn.className = 'lightbox-close';
  closeBtn.textContent = '✕ Close';
  closeBtn.addEventListener('click', () => lb.remove());

  lb.addEventListener('click', e => { if (e.target === lb) lb.remove(); });

  let media;
  if (item.type === 'image') {
    media = document.createElement('img');
    media.src = item.url;
    media.alt = '';
  } else if (item.type === 'video') {
    media = document.createElement('video');
    media.src = item.url;
    media.controls = true;
    media.autoplay = true;
    media.muted = false;
  }

  const urlLabel = document.createElement('div');
  urlLabel.className = 'lightbox-url';
  urlLabel.textContent = item.url;

  content.appendChild(closeBtn);
  if (media) content.appendChild(media);
  content.appendChild(urlLabel);
  lb.appendChild(content);
  document.body.appendChild(lb);
}

// ── Download ────────────────────────────────────────────────────
function downloadItem(item) {
  const filename = guessFilename(item);
  dlQueueEl.classList.remove('hidden');

  const qItem = { url: item.url, name: filename, progress: 0, status: 'pending' };
  dlQueue.push(qItem);
  renderDlQueue();

  chrome.downloads.download(
    { url: item.url, filename: filename, saveAs: false },
    (dlId) => {
      if (chrome.runtime.lastError) {
        qItem.status = 'err';
        renderDlQueue();
        return;
      }
      // Poll download state
      const interval = setInterval(() => {
        chrome.downloads.search({ id: dlId }, ([dl]) => {
          if (!dl) { clearInterval(interval); return; }
          if (dl.totalBytes > 0) {
            qItem.progress = Math.round((dl.bytesReceived / dl.totalBytes) * 100);
          }
          qItem.status = dl.state === 'complete' ? 'done'
                       : dl.state === 'interrupted' ? 'err'
                       : 'pending';
          renderDlQueue();
          if (dl.state === 'complete' || dl.state === 'interrupted') clearInterval(interval);
        });
      }, 400);
    }
  );
}

function guessFilename(item) {
  try {
    const path = new URL(item.url).pathname;
    const name = path.split('/').pop().split('?')[0];
    if (name && name.includes('.')) return name;
  } catch {}
  const exts = { video: '.mp4', audio: '.mp3', image: '.jpg', iframe: '.html' };
  return `media_${Date.now()}${exts[item.type] || ''}`;
}

function renderDlQueue() {
  dlList.innerHTML = '';
  dlQueue.forEach(q => {
    const row = document.createElement('div');
    row.className = 'dl-item';

    const name = document.createElement('div');
    name.className = 'dl-item-name';
    name.textContent = q.name;
    name.title = q.url;

    const wrap = document.createElement('div');
    wrap.className = 'dl-progress-wrap';
    const bar = document.createElement('div');
    bar.className = 'dl-progress-bar';
    bar.style.width = (q.status === 'done' ? 100 : q.progress) + '%';
    wrap.appendChild(bar);

    const st = document.createElement('div');
    st.className = 'dl-status' + (q.status === 'done' ? ' done' : q.status === 'err' ? ' err' : '');
    st.textContent = q.status === 'done' ? '✓' : q.status === 'err' ? '!' : q.progress + '%';

    row.appendChild(name);
    row.appendChild(wrap);
    row.appendChild(st);
    dlList.appendChild(row);
  });
}

clearQueueBtn.addEventListener('click', () => {
  dlQueue = [];
  dlQueueEl.classList.add('hidden');
});

// ── Search & Filter ─────────────────────────────────────────────
searchInp.addEventListener('input', e => {
  searchQuery = e.target.value.toLowerCase().trim();
  renderMedia();
});

document.querySelectorAll('.chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach(c => {
      c.className = 'chip';
    });
    activeFilter = chip.dataset.filter;
    chip.classList.add('active-' + activeFilter);
    renderMedia();
  });
});

// Stat tiles as quick filters
document.querySelectorAll('.stat-tile').forEach(tile => {
  tile.addEventListener('click', () => {
    const type = tile.dataset.type;
    document.querySelectorAll('.chip').forEach(c => {
      c.className = 'chip';
      if (c.dataset.filter === type) c.classList.add('active-' + type);
    });
    activeFilter = type;
    renderMedia();
  });
});

// ── Copy All ────────────────────────────────────────────────────
copyAllBtn.addEventListener('click', () => {
  const urls = getFiltered().map(m => m.url).join('\n');
  if (!urls) return;
  navigator.clipboard.writeText(urls).then(() => {
    copyAllBtn.textContent = '✓ Copied!';
    copyAllBtn.classList.add('success');
    setTimeout(() => { copyAllBtn.innerHTML = '<span>⊕</span> Copy All'; copyAllBtn.classList.remove('success'); }, 1800);
  });
});

// ── Export ──────────────────────────────────────────────────────
exportBtn.addEventListener('click', (e) => {
  exportMenu.classList.toggle('hidden');
  e.stopPropagation();
});
document.addEventListener('click', () => exportMenu.classList.add('hidden'));

$('expJson').addEventListener('click', () => {
  const data = JSON.stringify(getFiltered(), null, 2);
  saveFile(data, 'mediastream-export.json', 'application/json');
});

$('expCsv').addEventListener('click', () => {
  const rows = [['type','url','resolution','duration','size','isStream']];
  getFiltered().forEach(m => rows.push([m.type, m.url, m.resolution||'', m.duration||'', m.size||'', m.isStream ? 'yes' : 'no']));
  const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  saveFile(csv, 'mediastream-export.csv', 'text/csv');
});

$('expMd').addEventListener('click', () => {
  const lines = ['# MediaStream Export\n'];
  const typed = { video: [], audio: [], iframe: [], image: [] };
  getFiltered().forEach(m => (typed[m.type] || []).push(m));
  for (const [t, items] of Object.entries(typed)) {
    if (!items.length) continue;
    lines.push(`## ${t.charAt(0).toUpperCase() + t.slice(1)}s\n`);
    items.forEach(m => {
      if (t === 'image') lines.push(`![image](${m.url})`);
      else lines.push(`- [${m.url}](${m.url})`);
    });
    lines.push('');
  }
  saveFile(lines.join('\n'), 'mediastream-export.md', 'text/markdown');
});

function saveFile(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
  exportMenu.classList.add('hidden');
}

// ── Clear ───────────────────────────────────────────────────────
clearBtn.addEventListener('click', () => {
  allMedia = []; dlQueue = [];
  setDashboard(false);
  dlQueueEl.classList.add('hidden');
  searchInp.value = '';
  searchQuery = '';
  activeFilter = 'all';
  document.querySelectorAll('.chip').forEach(c => {
    c.className = 'chip';
    if (c.dataset.filter === 'all') c.classList.add('active-all');
  });
  setStatus('', 'idle');
  showReady();
});

// ── Empty / Error / Ready states ────────────────────────────────
function showReady() {
  mediaList.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.className = 'empty-state';
  wrap.innerHTML = `
    <div class="empty-icon-wrap">▶</div>
    <div class="empty-title">Ready to scan</div>
    <div class="empty-body">Click the button above to extract<br>videos, audio, iframes &amp; images.</div>
  `;
  mediaList.appendChild(wrap);
}

function showEmpty(title, body) {
  mediaList.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.className = 'empty-state';
  const icon = document.createElement('div');
  icon.className = 'empty-icon-wrap';
  icon.textContent = '⊘';
  const t = document.createElement('div');
  t.className = 'empty-title';
  t.textContent = title;
  const b = document.createElement('div');
  b.className = 'empty-body';
  b.textContent = body;
  wrap.appendChild(icon); wrap.appendChild(t); wrap.appendChild(b);
  mediaList.appendChild(wrap);
}

function showError(msg) {
  mediaList.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.className = 'empty-state';
  const icon = document.createElement('div');
  icon.className = 'empty-icon-wrap';
  icon.textContent = '!';
  const t = document.createElement('div');
  t.className = 'empty-title';
  t.textContent = 'Error';
  const b = document.createElement('div');
  b.className = 'empty-body';
  b.textContent = msg;
  wrap.appendChild(icon); wrap.appendChild(t); wrap.appendChild(b);
  mediaList.appendChild(wrap);
}

// ── Page Scanner (injected into page context) ───────────────────
function pageScanner() {
  const extracted = [];
  const seen = new Set();

  const push = (rawUrl, type, extra = {}) => {
    if (!rawUrl) return;
    if (rawUrl.startsWith('javascript:') || rawUrl === 'about:blank') return;
    if (rawUrl.startsWith('data:image')) return; // skip inline data URIs (too large)
    let url;
    try { url = new URL(rawUrl, document.baseURI || location.href).href; } catch { return; }
    if (seen.has(url)) return;
    seen.add(url);
    extracted.push({ url, type, ...extra });
  };

  // ── Videos
  document.querySelectorAll('video').forEach(v => {
    if (v.src) push(v.src, 'video');
    v.querySelectorAll('source').forEach(s => s.src && push(s.src, 'video'));
    // data-src lazy load
    const ds = v.getAttribute('data-src');
    if (ds) push(ds, 'video');
  });

  // ── Audio
  document.querySelectorAll('audio').forEach(a => {
    if (a.src) push(a.src, 'audio');
    a.querySelectorAll('source').forEach(s => s.src && push(s.src, 'audio'));
  });

  // ── iFrames
  document.querySelectorAll('iframe').forEach(f => {
    try { if (f.src && f.src !== 'about:blank') push(f.src, 'iframe'); } catch {}
  });

  // ── Images — <img> tags
  document.querySelectorAll('img').forEach(img => {
    const src = img.src || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.currentSrc;
    if (src) push(src, 'image');
    // srcset
    const srcset = img.getAttribute('srcset') || img.getAttribute('data-srcset');
    if (srcset) {
      srcset.split(',').forEach(part => {
        const s = part.trim().split(/\s+/)[0];
        if (s) push(s, 'image');
      });
    }
  });

  // ── <picture> sources
  document.querySelectorAll('picture source').forEach(s => {
    const srcset = s.srcset;
    if (srcset) {
      srcset.split(',').forEach(part => {
        const url = part.trim().split(/\s+/)[0];
        if (url) push(url, 'image');
      });
    }
  });

  // ── CSS background images (top 2000 elements to avoid slowdown)
  const allEls = Array.from(document.querySelectorAll('*')).slice(0, 2000);
  allEls.forEach(el => {
    try {
      const bg = window.getComputedStyle(el).backgroundImage;
      if (bg && bg !== 'none' && bg.includes('url(')) {
        // handle multiple backgrounds
        const matches = bg.matchAll(/url\(["']?([^"')]+)["']?\)/g);
        for (const m of matches) { if (m[1]) push(m[1], 'image'); }
      }
    } catch {}
  });

  // ── HLS (.m3u8) and DASH (.mpd) — scan all script/link tags and inline text
  const hlsPattern  = /https?:\/\/[^\s"'<>]+\.m3u8[^\s"'<>]*/g;
  const dashPattern = /https?:\/\/[^\s"'<>]+\.mpd[^\s"'<>]*/g;
  const htmlText = document.documentElement.innerHTML;

  const hlsMatches  = [...(htmlText.matchAll(hlsPattern)  || [])];
  const dashMatches = [...(htmlText.matchAll(dashPattern) || [])];

  hlsMatches.forEach(m  => push(m[0],  'video', { isStream: true }));
  dashMatches.forEach(m => push(m[0],  'video', { isStream: true }));

  // ── YouTube max-res thumbnail
  const yt = location.href.match(/(?:youtube\.com\/(?:[^/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?/ ]{11})/);
  if (yt?.[1]) push(`https://img.youtube.com/vi/${yt[1]}/maxresdefault.jpg`, 'image');

  // ── Open Graph / meta images
  document.querySelectorAll('meta[property="og:image"], meta[name="twitter:image"]').forEach(meta => {
    const c = meta.getAttribute('content');
    if (c) push(c, 'image');
  });

  return extracted;
}
