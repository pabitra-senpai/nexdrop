# MediaStream — Media Extractor v5.0

A Chrome extension (Manifest V3) that deep-scans any webpage and extracts every video, audio track, iFrame embed, HLS/DASH stream, and image — with one click.

---

## Features

### Scanning
| What it finds | How |
|---|---|
| `<video>` & `<source>` | Direct src, data-src lazy-load |
| `<audio>` & `<source>` | Direct src + lazy attributes |
| HLS streams (`.m3u8`) | Full HTML regex scan |
| DASH streams (`.mpd`) | Full HTML regex scan |
| `<iframe>` embeds | src attribute (cross-origin safe) |
| `<img>` tags | src, data-src, data-lazy-src, srcset, currentSrc |
| `<picture>` sources | All srcset candidates |
| CSS background images | Computed style on top 2000 elements |
| Open Graph / Twitter images | `<meta>` content attributes |
| YouTube max-res thumbnail | Auto-detected from page URL |

Scans all frames on the page (`allFrames: true`), deduplicates by URL.

### Preview
- **Image lightbox** — click the thumbnail to open a fullscreen preview
- **Video hover preview** — hover the thumbnail to play silently
- **Video lightbox** — click to open with full controls + audio
- **Duration badge** — loaded from video/audio metadata
- **Resolution badge** — natural width × height for images; video dimensions for video
- **File size badge** — fetched via HTTP HEAD request

### Filtering & Search
- Filter by type: All · Video · Audio · iFrame · Image · HLS/DASH
- Click stat tiles at the top to quick-filter
- Live URL search bar

### Download
- Per-item **Download** button — triggers Chrome's native download
- **Download queue panel** — shows real-time progress bar and status for every download
- Filenames auto-detected from URL path; fallback to `media_{timestamp}.ext`

### Export
- **Copy All** — copies all visible URLs to clipboard (respects active filter + search)
- **JSON** — full metadata export (url, type, resolution, duration, size, isStream)
- **CSV** — spreadsheet-ready
- **Markdown** — `![image](url)` for images, `- [url](url)` for other types

---

## File Structure

```
mediastream-v5/
├── manifest.json       # Extension manifest (MV3)
├── popup.html          # UI — styles + layout
├── popup.js            # All logic — scan, render, download, export
├── icons/
│   ├── icon16.svg      # Toolbar icon
│   ├── icon48.svg      # Extensions management page
│   └── icon128.svg     # Chrome Web Store / install screen
└── README.md
```

---

## Installation (Developer Mode)

1. Download or clone this folder.
2. Open Chrome and go to `chrome://extensions`.
3. Enable **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the `mediastream-v5` folder.
5. The MediaStream icon appears in your toolbar.

---

## Permissions

| Permission | Why it's needed |
|---|---|
| `activeTab` | Read the current tab's URL to validate before scanning |
| `scripting` | Inject the page scanner into the active tab and all its frames |
| `downloads` | Trigger file downloads from the Download buttons |
| `storage` | Reserved for future scan history feature |

No data is sent to any external server. All processing happens locally in your browser.

---

## Security

- **XSS-safe rendering** — all URLs and text are inserted via DOM text nodes or `textContent`, never `innerHTML` with raw user data.
- **URL validation** — only `http:`, `https:`, and `blob:` protocols are accepted; `javascript:` and `data:` URIs are rejected.
- **`chrome.runtime.lastError` handling** — all scripting and download calls check for runtime errors explicitly.
- **Fetch timeouts** — HEAD requests for file size use `AbortSignal.timeout(4000)` to avoid hanging.

---

## Changelog

### v5.0
- Complete UI redesign — Inter + JetBrains Mono, new color system, rounded cards
- Added Audio extraction (`<audio>` tags)
- Added HLS/DASH stream detection (`.m3u8`, `.mpd` regex scan)
- Added image lightbox and video lightbox
- Added video/audio duration and resolution from metadata
- Added image resolution from natural dimensions
- Added file size via HTTP HEAD
- Added Download button + queue panel with progress bars
- Added JSON, CSV, Markdown export
- Added `<picture>` srcset and Open Graph meta image detection
- Fixed XSS vulnerability in card rendering
- Fixed `chrome.runtime.lastError` not being checked
- Fixed `copyAllBtn` success state CSS missing
- Fixed list scroll (was unbounded in v4)
- Manifest updated: added `downloads` permission

### v4.1
- Initial public release

---

## License

MIT — free to use, modify, and distribute.
